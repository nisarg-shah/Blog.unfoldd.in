module.exports = {
  blog: require('./Blog'),
  users: require('./users'),
  comments: require('./comments')

};