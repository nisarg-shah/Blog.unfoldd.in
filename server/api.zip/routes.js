module.exports = {
  '/blog': require('./controllers/BlogController'),
  '/users': require('./controllers/UsersController'),
  '/comments': require('./controllers/CommentsController')


};